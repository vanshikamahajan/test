package stepdefinitions;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import io.cucumber.java.en.Given;

public class testjava {
	@Given("launch google and log")
	public void launch_google() throws MalformedURLException {
	   
	    System.setProperty("webdriver.chrome.driver","C://Users//Desktop//chromedriver.exe");
	    WebDriver driver = new ChromeDriver();
	    driver.get("https://accounts.datoms.io/login");
	    try{
	    	WebElement email = driver.findElement(By.xpath("//input[@id='email']"));
	    	email.click();
	    	email.sendKeys("mahajanvanshika987@gmail.com");
	    	Thread.sleep(1000);
	    	
	    }
	    catch(Exception e1){
	    	System.out.println("element not found");
	    	
	    }
	    
	    try{
	    	WebElement password = driver.findElement(By.xpath("//input[@aria-label='password']"));
	    	password.click();
	    	password.sendKeys("mypassword");
	    	Thread.sleep(1000);
	    }
	    catch(Exception e1){
	    	
	    }
	    
	    try{
	    	WebElement login = driver.findElement(By.xpath("//input[@value='Login']"));
	    	login.click();
	    }
	    catch(Exception e1){
	    	System.out.println("login button not found");
	    }
	    
	    driver.quit();
	    
	}
}